//
//  AppDelegate.h
//  iDev_Crypto
//
//  Created by Niketan Mishra on 4/24/13.
//  Copyright (c) 2013 SparshInc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
